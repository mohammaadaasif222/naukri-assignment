import React from "react";
import "./program.css";
const Programm = () => {
  return (
    <section className="data-pointers section py-5 " id=" ">
      <div className="container">
        <div className="row">
          <div className="stats-content">
            <h2 className="section-heading">
              <span className="section-overline">Learn Data Science from</span><br/>
              India's Most Trusted Program
            </h2>
            <p className="section-subtitle">
              Over 25,000+ learners rated this program 4.7/5, under the guidance
              of 2500+ industry mentors
            </p>
          </div>
        </div>
        <div className="container " style={{width:'80%'}}>
          <div className="row">
            
          <div className="col-md-4">
            <div className="stats-card__item ">
              <p className="stats-card__data">66%</p>
              <p className="stats-card__desc">Alumni Career Transitions</p>
            </div>
          </div>
          <div className="col-md-4">
          <div className="stats-card__item">
            <p className="stats-card__data" style={{color:'#e69000'}}>3000+</p>
              <p className="stats-card__desc">Hiring Companies</p>
          </div>
          </div>
          <div className="col-md-4">
            <div className="stats-card__item">
              <p className="stats-card__data" style={{color:'#990eb7'}}>55%</p>
              <p className="stats-card__desc">Avg. Salary Hike</p>
            </div>
          </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Programm;
