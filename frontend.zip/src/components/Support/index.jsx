import React from "react";

const Support = () => {
  return (
      <div className="container">
        <div class="section-head">
          <h2 class="section-heading">
            <span class="section-overline">
              Get access to curated jobs with
            </span>
            Dedicated Career Support
          </h2>
        </div>
        <div className="row">
          <div className="col-md-3">
            {" "}
            <div
              class="career-growth-card card lazy"
              src="https://d1vwxdpzbgdqj.cloudfront.net/s3-public-images/placeholder.png"
              data-src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/career-growth-pic-1.jpg"
            >
              <section class="career-growth-card-content">
                <p class="career-growth-card__title">
                  Access to 100+ job postings every month
                </p>
              </section>
            </div>
          </div>
          <div className="col-md-3">
            <div
              class="career-growth-card card lazy"
              src="https://d1vwxdpzbgdqj.cloudfront.net/s3-public-images/placeholder.png"
              data-src="https://d1vwxdpzbgdqj.cloudfront.net/mba-courses/learner-pic-2.jpg"
            >
              <section class="career-growth-card-content">
                <p class="career-growth-card__title">
                  Personalized resume & Linkedin review
                </p>
              </section>
            </div>
          </div>
          <div className="col-md-3">
            <div
              class="career-growth-card card lazy"
              src="https://d1vwxdpzbgdqj.cloudfront.net/s3-public-images/placeholder.png"
              data-src="https://d1vwxdpzbgdqj.cloudfront.net/mba-courses/learner-pic-3.jpg"
            >
              <section class="career-growth-card-content">
                <p class="career-growth-card__title">
                  Live career mentorship with industry experts
                </p>
              </section>
            </div>
          </div>
          <div className="col-md-3">
            <div
              class="career-growth-card card lazy"
              src="https://d1vwxdpzbgdqj.cloudfront.net/s3-public-images/placeholder.png"
              data-src="https://d1vwxdpzbgdqj.cloudfront.net/mba-courses/learner-pic-4.jpg"
            >
              <section class="career-growth-card-content">
                <p class="career-growth-card__title">
                  Mock interviews with industry experts
                </p>
              </section>
            </div>
          </div>
        </div>
      </div>
   
  );
};

export default Support;
