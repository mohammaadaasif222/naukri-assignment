import React from "react";
import "./careers.css";
import Carousel from "react-bootstrap/Carousel";
const Careers = () => {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-6 px-4">
          <div className="section-head content-section container">
            <h2 className="section-heading">1,000s of careers transformed</h2>
            <p className="section-subtitle text-left">
              A few of our alumni share their experience of the program
            </p>
            <div className="gl-slider-btns">
              <div className="gl-slider-nav js-nav-prev">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M15 9H3.83L8.71 13.88C9.1 14.27 9.1 14.91 8.71 15.3C8.32 15.69 7.69 15.69 7.3 15.3L0.709999 8.71C0.319999 8.32 0.319999 7.69 0.709999 7.3L7.29 0.700001C7.68 0.310001 8.31 0.310001 8.7 0.700001C9.09 1.09 9.09 1.72 8.7 2.11L3.83 7H15C15.55 7 16 7.45 16 8C16 8.55 15.55 9 15 9Z"
                    fill="#323232"
                  ></path>
                </svg>
              </div>
              <div className="gl-slider-nav js-nav-next">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M1.4175 9H12.5875L7.7075 13.88C7.3175 14.27 7.3175 14.91 7.7075 15.3C8.0975 15.69 8.72749 15.69 9.11749 15.3L15.7075 8.71C16.0975 8.32 16.0975 7.69 15.7075 7.3L9.12749 0.700001C8.73749 0.310001 8.1075 0.310001 7.7175 0.700001C7.3275 1.09 7.3275 1.72 7.7175 2.11L12.5875 7H1.4175C0.867496 7 0.417496 7.45 0.417496 8C0.417496 8.55 0.867496 9 1.4175 9Z"
                    fill="#323232"
                  ></path>
                </svg>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 py-5">
          <Carousel data-bs-theme="dark" className="second-slider">
            <Carousel.Item className="testimonial-card">
              <div className="testimonial-card">
                <div className="comp-logo-wrapper">
                  <img
                    src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/deutsche-bank.jpg"
                    alt="company logo"
                    className="lazy comp-logo "
                  />
                </div>
                <p className="testimonial-card__desc">
                  The job offer from Deutsche Bank is the best one I got with a
                  hike close to 60 percent.
                </p>
                <div className="learner">
                  <div
                    className="learner__avatar lazy"
                    data-src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/abhishek-das.jpg"
                  ></div>
                  <div className="learner-detail">
                    <p className="learner-detail__name">Abhishek Das</p>
                    <p className="learner-detail__designation color-blue">
                      Technology Service Analyst
                    </p>
                  </div>
                </div>
              </div>
            </Carousel.Item>
            <Carousel.Item className="testimonial-card">
              <div className="testimonial-card">
                <div className="comp-logo-wrapper">
                  <img
                    src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/deutsche-bank.jpg"
                    alt="company logo"
                    className="lazy comp-logo "
                  />
                </div>
                <p className="testimonial-card__desc">
                  The job offer from Deutsche Bank is the best one I got with a
                  hike close to 60 percent.
                </p>
                <div className="learner">
                  <div
                    className="learner__avatar lazy"
                    src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/abhishek-das.jpg"
                  ></div>
                  <div className="learner-detail">
                    <p className="learner-detail__name">Abhishek Das</p>
                    <p className="learner-detail__designation color-blue">
                      Technology Service Analyst
                    </p>
                  </div>
                </div>
              </div>
            </Carousel.Item>
            <Carousel.Item className="testimonial-card">
              <div className="testimonial-card">
                <div className="comp-logo-wrapper">
                  <img
                    src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/advance-auto-parts.jpg"
                    alt="company logo"
                    className="lazy comp-logo "
                  />
                </div>
                <p className="testimonial-card__desc">
                  I was able to switch from Banking to Analytics domain. It is
                  really thrilling to move to a new role.
                </p>
                <div className="learner">
                  <div
                    className="learner__avatar lazy"
                    data-src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/sandeep-sarangi.jpg"
                  ></div>
                  <div className="learner-detail">
                    <p className="learner-detail__name">Sandip Sarangi</p>
                    <p className="learner-detail__designation color-blue">
                      Senior Pricing Analyst
                    </p>
                  </div>
                </div>
              </div>
            </Carousel.Item>
            <Carousel.Item className="testimonial-card">
              <div className="testimonial-card">
                <div className="comp-logo-wrapper">
                  <img
                    src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/deloitte.jpg"
                    alt="company logo"
                    className="lazy comp-logo "
                  />
                </div>
                <p className="testimonial-card__desc">
                  Cracked interview at Deloitte Consulting due to this
                  exceptional program.
                </p>
                <div className="learner">
                  <div
                    className="learner__avatar lazy"
                    data-src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/palanivel-murugan.jpg"
                  ></div>
                  <div className="learner-detail">
                    <p className="learner-detail__name">Palanivel Murgan</p>
                    <p className="learner-detail__designation color-blue">
                      Senior Consultant
                    </p>
                  </div>
                </div>
              </div>
            </Carousel.Item>
            <Carousel.Item className="testimonial-card">
              <div className="testimonial-card">
                <div className="comp-logo-wrapper">
                  <img
                    src="https://d1vwxdpzbgdqj.cloudfront.net/great-lakes-pgpba-new/KPMG.png"
                    alt="company logo"
                    className="lazy comp-logo "
                  />
                </div>
                <p className="testimonial-card__desc">
                  Got into the Big 4 as a Data Analyst due to constant mentor
                  guidance.
                </p>
                <div className="learner">
                  <div
                    className="learner__avatar lazy"
                    data-src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/srinidhi-dewan.jpg"
                  ></div>
                  <div className="learner-detail">
                    <p className="learner-detail__name">Srinidhi Devan</p>
                    <p className="learner-detail__designation color-blue">
                      Data Warehousing
                    </p>
                  </div>
                </div>
              </div>
            </Carousel.Item>
            <Carousel.Item className="testimonial-card">
              <div className="testimonial-card">
                <div className="comp-logo-wrapper">
                  <img
                    src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/oyo-logo.jpg"
                    alt="company logo"
                    className="lazy comp-logo "
                  />
                </div>
                <p className="testimonial-card__desc">
                  I finally got a promotion at OYO after struggling for more
                  than 2 years, only due to this program.
                </p>
                <div className="learner">
                  <div
                    className="learner__avatar lazy"
                    data-src="https://d1vwxdpzbgdqj.cloudfront.net/dsba-lp-new/testimonial-data/vishal-srivastava.jpg"
                  ></div>
                  <div className="learner-detail">
                    <p className="learner-detail__name">Vishal Srivastava</p>
                    <p className="learner-detail__designation color-blue">
                      Senior Business Analyst
                    </p>
                  </div>
                </div>
              </div>
            </Carousel.Item>
          </Carousel>
        </div>
      </div>
    </div>
  );
};

export default Careers;
