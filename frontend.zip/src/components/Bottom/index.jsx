import React from "react";

const Bottom = () => {
  return (
    <section className="bottom-snackbar-line">
      <div className="container">
        <p className="snackbar-text mb-0">
          With 6 Week Microsoft Power BI Data Analyst Training Program
          (Optional)
        </p>
      </div>
      
    </section>
  );
};

export default Bottom;
