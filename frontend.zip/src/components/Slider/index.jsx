import Carousel from "react-bootstrap/Carousel";

function Slider() {
  return (
    <Carousel data-bs-theme="dark" style={{ marginTop: "5rem" }}>
      <Carousel.Item style={{ height: "90vh" }}>
        <div className="row p-5">
          <div className="col-md-6">
             
          </div>
          <div className="col-md-6">
            {" "}
            <img
              className="d-block w-85"
              src="https://d1vwxdpzbgdqj.cloudfront.net/home-new-variant/data-science-banner.png"
              alt="First slide"
            />
          </div>
        </div>

      </Carousel.Item>
      <Carousel.Item style={{ height: "90vh" }}>
        <div className="row">
          <div className="col-md-6">
            <h1>First Slider</h1>
          </div>
          <div className="col-md-6">
            {" "}
            <img
              className="d-block w-85"
              src="https://d1vwxdpzbgdqj.cloudfront.net/home-new-variant/main-home-banner.png"
              alt="First slide"
            />
          </div>
        </div>
      </Carousel.Item>
      <Carousel.Item style={{ height: "90vh" }}>
        <div className="row">
          <div className="col-md-6">
            <h1>First Slider</h1>
          </div>
          <div className="col-md-6">
            {" "}
            <img
              className="d-block w-85"
              src="https://d1vwxdpzbgdqj.cloudfront.net/home-new-variant/study-abroad-banner.png"
              alt="First slide"
            />
          </div>
        </div>

      </Carousel.Item>
      <Carousel.Item style={{ height: "90vh" }}>
        <div className="row">
          <div className="col-md-6">
            <h1>First Slider</h1>
          </div>
          <div className="col-md-6">
            {" "}
            <img
              className="d-block w-85"
              src="https://d1vwxdpzbgdqj.cloudfront.net/home-new-variant/aiml-banner.png"
              alt="First slide"
            />
          </div>
        </div>
      </Carousel.Item>
    </Carousel>
  );
}

export default Slider;
