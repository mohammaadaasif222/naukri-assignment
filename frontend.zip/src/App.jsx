import './App.css'
import NavBar from './components/NavBar'
import Slider from './components/Slider'
// import Banner from './components/Banner'
import Programm from './components/Program'
import Bottom from './components/Bottom'
import Careers from './components/Careers'
import Support from './components/Support'

function App() {
  return (
    <>
     <NavBar/>
     <Slider/>
     <Bottom/>
     <Programm/>
     <Careers/>
     <Support/>
     {/* <Banner/> */}
    </>
  )
}

export default App
